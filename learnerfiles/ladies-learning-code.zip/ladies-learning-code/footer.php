<div class="footer">
	<div class="innerWrapper">
    <p>&copy; Your Name Here</p>
    <?php wp_footer(); ?>
  </div>
</div>

</body>
</html>