<form role="search" method="get" id="searchform" action="<?php bloginfo('url'); ?>">
	<input type="text" placeholder="Search..." title="Search..." name="s" id="s" >
	<input type="submit" class="searchsubmit" value="Search">
</form>