<div class="sidebar">
  <?php /* ======= Start: Put your Picture here! ======== */ ?>
      
  <?php /* ======= Stop: Put your Picture here! ======== */ ?>
	<ul class="xoxo">
		<?php  dynamic_sidebar( 'primary-widget-area' ); ?>
	</ul>
</div>
	
